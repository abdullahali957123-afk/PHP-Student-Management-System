
<?php
require __DIR__ . '/config.php';

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    http_response_code(400);
    exit('Invalid student ID.');
}

$stmt = $conn->prepare(
    'SELECT id, full_name, email, course
     FROM students WHERE id = ?'
);

$stmt->bind_param('i', $id);
$stmt->execute();

$student = $stmt->get_result()->fetch_assoc();

if (!$student) {
    http_response_code(404);
    exit('Student record not found.');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $fullName = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $course = trim($_POST['course'] ?? '');

    if ($fullName === '' || $course === '') {
        $error = 'Name and course are required.';

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Enter a valid email address.';

    } else {

        try {
            $update = $conn->prepare(
                'UPDATE students
                 SET full_name = ?, email = ?, course = ?
                 WHERE id = ?'
            );

            $update->bind_param(
                'sssi',
                $fullName,
                $email,
                $course,
                $id
            );

            $update->execute();

            header('Location: index.php?status=updated');
            exit;

        } catch (mysqli_sql_exception $e) {
            error_log('Student update failed: ' . $e->getMessage());
            $error = 'Unable to update. Email may already be in use.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Student</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<main class="container">

    <section class="panel">

        <h1>Edit Student</h1>

        <?php if ($error !== ''): ?>
            <p class="message error"><?= e($error) ?></p>
        <?php endif; ?>

        <form method="POST" action="edit.php?id=<?= e($id) ?>">

            <label>Full Name</label>
            <input type="text" name="full_name"
                   maxlength="100" required
                   value="<?= e($_POST['full_name'] ?? $student['full_name']) ?>">

            <label>Email Address</label>
            <input type="email" name="email"
                   maxlength="150" required
                   value="<?= e($_POST['email'] ?? $student['email']) ?>">

            <label>Course</label>
            <input type="text" name="course"
                   maxlength="100" required
                   value="<?= e($_POST['course'] ?? $student['course']) ?>">

            <button type="submit">Save Changes</button>

            <a class="back-link" href="index.php">Cancel</a>

        </form>

    </section>

</main>

</body>
</html>
