
<?php
require __DIR__ . '/config.php';

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_student'])) {

    $fullName = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $course = trim($_POST['course'] ?? '');

    if ($fullName === '' || $course === '') {
        $error = 'Name and course are required.';

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Enter a valid email address.';

    } else {
        try {
            $stmt = $conn->prepare(
                'INSERT INTO students (full_name, email, course)
                 VALUES (?, ?, ?)'
            );

            $stmt->bind_param('sss', $fullName, $email, $course);
            $stmt->execute();

            header('Location: index.php?status=added');
            exit;

        } catch (mysqli_sql_exception $e) {
            error_log('Student insert failed: ' . $e->getMessage());
            $error = 'Unable to add student. Email may already exist.';
        }
    }
}

if (($_GET['status'] ?? '') === 'added') {
    $message = 'Student added successfully!';
} elseif (($_GET['status'] ?? '') === 'updated') {
    $message = 'Student updated successfully!';
} elseif (($_GET['status'] ?? '') === 'deleted') {
    $message = 'Student deleted successfully!';
}

$result = $conn->query(
    'SELECT id, full_name, email, course, created_at
     FROM students ORDER BY id DESC'
);

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Management System</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<main class="container">

    <h1>Student Management System</h1>
    <p class="intro">Add, View, Edit and Delete Student Records</p>

    <?php if ($message !== ''): ?>
        <p class="message success"><?= e($message) ?></p>
    <?php endif; ?>

    <?php if ($error !== ''): ?>
        <p class="message error"><?= e($error) ?></p>
    <?php endif; ?>

    <section class="panel">

        <h2>Add a Student</h2>

        <form method="POST" action="index.php">

            <label>Full Name</label>
            <input type="text" name="full_name"
                   maxlength="100" required>

            <label>Email Address</label>
            <input type="email" name="email"
                   maxlength="150" required>

            <label>Course</label>
            <input type="text" name="course"
                   maxlength="100" required>

            <button type="submit" name="add_student">
                Add Student
            </button>

        </form>

    </section>

    <section class="panel">

        <h2>Student Records</h2>

        <?php if ($result->num_rows === 0): ?>

            <p>No student records yet.</p>

        <?php else: ?>

        <div class="table-wrap">

            <table>

                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Full Name</th>
                        <th>Email</th>
                        <th>Course</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>

                <?php while ($student = $result->fetch_assoc()): ?>

                    <tr>
                        <td><?= e($student['id']) ?></td>
                        <td><?= e($student['full_name']) ?></td>
                        <td><?= e($student['email']) ?></td>
                        <td><?= e($student['course']) ?></td>
                        <td><?= e($student['created_at']) ?></td>

                        <td class="actions">

                            <a href="edit.php?id=<?= e($student['id']) ?>">
                                Edit
                            </a>

                            <form class="inline-form"
                                  method="POST"
                                  action="delete.php"
                                  onsubmit="return confirm('Delete this student?');">

                                <input type="hidden" name="id"
                                       value="<?= e($student['id']) ?>">

                                <button class="danger" type="submit">
                                    Delete
                                </button>

                            </form>

                        </td>
                    </tr>

                <?php endwhile; ?>

                </tbody>

            </table>

        </div>

        <?php endif; ?>

    </section>

</main>

</body>
</html>
