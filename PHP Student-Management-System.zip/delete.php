
<?php

require __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

$id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    http_response_code(400);
    exit('Invalid student ID.');
}

try {

    $stmt = $conn->prepare(
        'DELETE FROM students WHERE id = ?'
    );

    $stmt->bind_param('i', $id);
    $stmt->execute();

    header('Location: index.php?status=deleted');
    exit;

} catch (mysqli_sql_exception $e) {

    error_log('Student delete failed: ' . $e->getMessage());

    http_response_code(500);
    exit('Unable to delete this record right now.');
}

?>
