from io import BytesIO

import pdfplumber
from docx import Document
from flask import Flask, jsonify, render_template, request

from utils.analyzer import analyze_cv
from utils.cv_parser import parse_cv
from utils.matcher import match_job
from utils.roadmap import build_roadmap

app = Flask(__name__)

MAX_SIZE = 5 * 1024 * 1024  # 5 MB
app.config["MAX_CONTENT_LENGTH"] = MAX_SIZE
ALLOWED = {"pdf", "docx"}


def extract_pdf(data):
    text = ""
    with pdfplumber.open(BytesIO(data)) as pdf:
        for page in pdf.pages:
            text += (page.extract_text() or "") + "\n"
    return text.strip()


def extract_docx(data):
    doc = Document(BytesIO(data))
    lines = [p.text for p in doc.paragraphs if p.text.strip()]
    return "\n".join(lines).strip()


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/api/upload", methods=["POST"])
def upload():
    file = request.files.get("cv")

    if file is None or file.filename == "":
        return jsonify({"error": "No file was received."}), 400

    ext = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else ""
    if ext not in ALLOWED:
        return jsonify({"error": "Only PDF or DOCX files are allowed."}), 400

    data = file.read()
    if len(data) == 0:
        return jsonify({"error": "The file is empty."}), 400

    try:
        text = extract_pdf(data) if ext == "pdf" else extract_docx(data)
    except Exception:
        return jsonify({"error": "The file could not be read. It may be corrupted."}), 422

    if not text:
        return jsonify({
            "error": "No text was found in the file. It may be a scanned or image-based file."
        }), 422

    return jsonify({
        "filename": file.filename,
        "text": text,
        "sections": parse_cv(text),
    })


@app.route("/api/analyze", methods=["POST"])
def analyze():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify({"error": "Invalid data received."}), 400
    return jsonify(analyze_cv(data))


@app.route("/api/match", methods=["POST"])
def match():
    payload = request.get_json(silent=True)
    if not isinstance(payload, dict) or not isinstance(payload.get("cv"), dict):
        return jsonify({"error": "Invalid data received."}), 400
    job = str(payload.get("job", "")).strip()
    if len(job) < 30:
        return jsonify({"error": "The job description is too short. Please paste the full description."}), 400
    if len(job) > 10000:
        return jsonify({"error": "The job description is too long (maximum 10,000 characters)."}), 400
    try:
        return jsonify(match_job(payload["cv"], job))
    except ValueError as e:
        return jsonify({"error": str(e)}), 422


@app.route("/api/roadmap", methods=["POST"])
def roadmap():
    payload = request.get_json(silent=True)
    if not isinstance(payload, dict):
        return jsonify({"error": "Invalid data received."}), 400
    lists = []
    for key in ("required", "preferred"):
        lst = payload.get(key, [])
        if not isinstance(lst, list) or len(lst) > 100:
            return jsonify({"error": "Invalid data received."}), 400
        clean = []
        for it in lst:
            if not isinstance(it, dict) or not isinstance(it.get("skill"), str) \
                    or it.get("status") not in ("matched", "partial", "missing"):
                return jsonify({"error": "Invalid data received."}), 400
            clean.append({"skill": it["skill"], "status": it["status"]})
        lists.append(clean)
    return jsonify(build_roadmap(lists[0], lists[1]))


@app.errorhandler(413)
def too_large(e):
    return jsonify({"error": "The file is too large. Maximum size is 5 MB."}), 413


if __name__ == "__main__":
    app.run(debug=True)
